# Meu Caderno Social — Flutter

Projeto-base multiplataforma para Android e iPadOS, com interface em português e identidade visual roxa.

## Executar
1. Instale Flutter SDK e Android Studio (Android) ou Xcode (iPadOS/macOS).
2. Na pasta do projeto, execute:
   ```bash
   flutter pub get
   flutter run
   ```

## Estrutura
- `lib/main.dart`: inicialização e tema.
- `lib/models/`: modelos.
- `lib/screens/`: telas.
- `lib/services/`: notificações e persistência local.
- `lib/screens/estrutura_estudos_screen.dart`: áreas, disciplinas/eixos e cadernos com anotações digitadas.
- `lib/models/item_estudo.dart`: estrutura dos itens de estudo.

## Notificações
O serviço agenda aviso às 09h, dois dias antes da data do evento. O usuário precisa conceder permissões. Em Android, alarmes exatos e notificações podem exigir permissões específicas conforme a versão do sistema. Em iOS/iPadOS, o sistema pode limitar a entrega conforme permissões e políticas do sistema.

## Observações importantes
- O canvas atual filtra toque quando o modo Caneta está ativado, mas a rejeição de palma real depende também do digitalizador, do sistema operacional e do fabricante da caneta/tablet. Testar em cada dispositivo.
- A agenda e eventos são persistidos localmente com SharedPreferences. Para muitos arquivos, páginas vetoriais, PDFs e sincronização entre dispositivos, migrar para banco local estruturado e backend/sincronização.
- A estrutura local de áreas, disciplinas/eixos e cadernos já está incluída nesta etapa. As anotações digitadas são salvas localmente. Ainda faltam escrita vetorial persistente por página, biblioteca PDF, fichamentos, diário de campo, exportação PDF e sincronização em nuvem (fora do escopo escolhido nesta versão).
- Antes de distribuir, configurar ícones, permissões nativas e testes em aparelhos reais.
