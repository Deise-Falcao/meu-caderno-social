class ItemEstudo {
  final String id;
  final String nome;
  final String tipo; // area, disciplina, caderno, anotacao
  final String? paiId;
  final String conteudo;
  final DateTime atualizadoEm;

  const ItemEstudo({
    required this.id,
    required this.nome,
    required this.tipo,
    this.paiId,
    this.conteudo = '',
    required this.atualizadoEm,
  });

  ItemEstudo copiar({
    String? nome,
    String? conteudo,
    DateTime? atualizadoEm,
  }) => ItemEstudo(
    id: id, nome: nome ?? this.nome, tipo: tipo, paiId: paiId,
    conteudo: conteudo ?? this.conteudo,
    atualizadoEm: atualizadoEm ?? this.atualizadoEm,
  );

  Map<String, dynamic> toJson() => {
    'id': id, 'nome': nome, 'tipo': tipo, 'paiId': paiId,
    'conteudo': conteudo, 'atualizadoEm': atualizadoEm.toIso8601String(),
  };

  factory ItemEstudo.fromJson(Map<String, dynamic> j) => ItemEstudo(
    id: j['id'] as String,
    nome: j['nome'] as String,
    tipo: j['tipo'] as String,
    paiId: j['paiId'] as String?,
    conteudo: (j['conteudo'] as String?) ?? '',
    atualizadoEm: DateTime.parse(j['atualizadoEm'] as String),
  );
}
