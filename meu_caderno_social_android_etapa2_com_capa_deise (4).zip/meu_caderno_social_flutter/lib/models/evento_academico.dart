class EventoAcademico {
  final int id;
  final String titulo;
  final String categoria;
  final String materia;
  final DateTime data;
  final String observacoes;

  const EventoAcademico({
    required this.id,
    required this.titulo,
    required this.categoria,
    required this.materia,
    required this.data,
    this.observacoes = '',
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'titulo': titulo,
    'categoria': categoria,
    'materia': materia,
    'data': data.toIso8601String(),
    'observacoes': observacoes,
  };

  factory EventoAcademico.fromJson(Map<String, dynamic> json) =>
      EventoAcademico(
        id: json['id'] as int,
        titulo: json['titulo'] as String,
        categoria: json['categoria'] as String,
        materia: json['materia'] as String,
        data: DateTime.parse(json['data'] as String),
        observacoes: (json['observacoes'] as String?) ?? '',
      );
}
