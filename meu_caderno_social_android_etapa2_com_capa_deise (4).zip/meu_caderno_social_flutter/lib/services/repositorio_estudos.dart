import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/item_estudo.dart';

class RepositorioEstudos {
  static const _chave = 'meu_caderno_estrutura_v1';

  Future<List<ItemEstudo>> carregar() async {
    final prefs = await SharedPreferences.getInstance();
    final bruto = prefs.getString(_chave);
    if (bruto == null) return [];
    try {
      final lista = jsonDecode(bruto) as List<dynamic>;
      return lista.map((e) => ItemEstudo.fromJson(e as Map<String, dynamic>)).toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> salvar(List<ItemEstudo> itens) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_chave, jsonEncode(itens.map((e) => e.toJson()).toList()));
  }
}
