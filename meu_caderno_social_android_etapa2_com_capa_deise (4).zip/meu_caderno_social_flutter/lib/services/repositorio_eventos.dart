import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/evento_academico.dart';

class RepositorioEventos {
  static const _chave = 'eventos_academicos_v1';

  Future<List<EventoAcademico>> carregar() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_chave);
    if (raw == null) return [];
    final lista = jsonDecode(raw) as List<dynamic>;
    return lista
        .map((e) => EventoAcademico.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  Future<void> salvar(List<EventoAcademico> eventos) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _chave,
      jsonEncode(eventos.map((e) => e.toJson()).toList()),
    );
  }
}
