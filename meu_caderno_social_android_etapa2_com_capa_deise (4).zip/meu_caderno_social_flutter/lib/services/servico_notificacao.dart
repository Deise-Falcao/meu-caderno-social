import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

class ServicoNotificacao {
  static final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  static Future<void> inicializar() async {
    tzdata.initializeTimeZones();
    tz.setLocalLocation(tz.getLocation('America/Sao_Paulo'));

    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const ios = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );
    await _plugin.initialize(
      const InitializationSettings(android: android, iOS: ios),
    );

    final androidPlugin = _plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    await androidPlugin?.requestNotificationsPermission();
    await androidPlugin?.requestExactAlarmsPermission();
  }

  static Future<void> agendarAvisoTrabalho({
    required int id,
    required String titulo,
    required String materia,
    required DateTime dataEntrega,
  }) async {
    final aviso = DateTime(
      dataEntrega.year, dataEntrega.month, dataEntrega.day - 2, 9,
    );
    if (!aviso.isAfter(DateTime.now())) return;

    const detalhesAndroid = AndroidNotificationDetails(
      'prazos_academicos',
      'Prazos acadêmicos',
      channelDescription: 'Avisos de provas, trabalhos e seminários',
      importance: Importance.max,
      priority: Priority.high,
    );
    const detalhes = NotificationDetails(
      android: detalhesAndroid,
      iOS: DarwinNotificationDetails(),
    );

    await _plugin.zonedSchedule(
      id,
      'Prazo chegando! ⏳',
      'Faltam 2 dias para "$titulo" de $materia.',
      tz.TZDateTime.from(aviso, tz.local),
      detalhes,
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      payload: id.toString(),
    );
  }

  static Future<void> cancelar(int id) => _plugin.cancel(id);
}
