import 'package:flutter/material.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'screens/inicio_screen.dart';
import 'services/servico_notificacao.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('pt_BR', null);
  await ServicoNotificacao.inicializar();
  runApp(const MeuCadernoSocialApp());
}

class MeuCadernoSocialApp extends StatelessWidget {
  const MeuCadernoSocialApp({super.key});

  @override
  Widget build(BuildContext context) {
    const roxo = Color(0xFF633A8B);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Meu Caderno Social',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: roxo),
        scaffoldBackgroundColor: const Color(0xFFF8F5FB),
        appBarTheme: const AppBarTheme(
          backgroundColor: roxo,
          foregroundColor: Colors.white,
          centerTitle: false,
        ),
        cardTheme: CardTheme(
          color: Colors.white,
          elevation: 1,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        ),
      ),
      home: const InicioScreen(),
    );
  }
}
