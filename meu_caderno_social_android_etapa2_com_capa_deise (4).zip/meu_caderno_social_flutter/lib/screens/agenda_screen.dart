import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:intl/intl.dart';
import '../models/evento_academico.dart';
import '../services/servico_notificacao.dart';
import '../services/repositorio_eventos.dart';

class AgendaServicoSocial extends StatefulWidget {
  const AgendaServicoSocial({super.key});
  @override
  State<AgendaServicoSocial> createState() => _AgendaServicoSocialState();
}

class _AgendaServicoSocialState extends State<AgendaServicoSocial> {
  final _repositorio = RepositorioEventos();
  final Map<DateTime, List<EventoAcademico>> _eventos = {};
  DateTime _focado = DateTime.now();
  DateTime? _selecionado;
  bool _carregando = true;

  DateTime _normalizar(DateTime d) => DateTime(d.year, d.month, d.day);

  @override
  void initState() {
    super.initState();
    _selecionado = _normalizar(_focado);
    _carregar();
  }

  Future<void> _carregar() async {
    final eventos = await _repositorio.carregar();
    if (!mounted) return;
    setState(() {
      _eventos.clear();
      for (final e in eventos) {
        _eventos.putIfAbsent(_normalizar(e.data), () => []).add(e);
      }
      _carregando = false;
    });
  }

  List<EventoAcademico> _doDia(DateTime? dia) =>
      _eventos[_normalizar(dia ?? _selecionado ?? DateTime.now())] ?? [];

  Future<void> _salvarEvento() async {
    final titulo = TextEditingController();
    final materia = TextEditingController();
    final observacoes = TextEditingController();
    String categoria = 'Trabalho';
    DateTime data = _selecionado ?? DateTime.now();

    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context, setDialog) =>
        AlertDialog(
          title: const Text('Novo compromisso'),
          content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: titulo, decoration: const InputDecoration(labelText: 'Nome da prova ou trabalho')),
            TextField(controller: materia, decoration: const InputDecoration(labelText: 'Disciplina')),
            DropdownButtonFormField<String>(
              value: categoria,
              items: ['Trabalho', 'Prova', 'Seminário', 'Entrega'].map((v) =>
                DropdownMenuItem(value: v, child: Text(v))).toList(),
              onChanged: (v) => setDialog(() => categoria = v ?? 'Trabalho'),
              decoration: const InputDecoration(labelText: 'Categoria'),
            ),
            TextButton.icon(
              icon: const Icon(Icons.event),
              label: Text(DateFormat('dd/MM/yyyy', 'pt_BR').format(data)),
              onPressed: () async {
                final d = await showDatePicker(
                  context: context, initialDate: data,
                  firstDate: DateTime(2020), lastDate: DateTime(2035),
                  locale: const Locale('pt', 'BR'),
                );
                if (d != null) setDialog(() => data = d);
              },
            ),
            TextField(controller: observacoes, maxLines: 2,
              decoration: const InputDecoration(labelText: 'Observações')),
          ])),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Salvar')),
          ],
        )),
    );

    if (ok == true && titulo.text.trim().isNotEmpty && materia.text.trim().isNotEmpty) {
      final evento = EventoAcademico(
        id: DateTime.now().microsecondsSinceEpoch,
        titulo: titulo.text.trim(),
        categoria: categoria,
        materia: materia.text.trim(),
        data: data,
        observacoes: observacoes.text.trim(),
      );
      final todos = _eventos.values.expand((e) => e).toList()..add(evento);
      await _repositorio.salvar(todos);
      await ServicoNotificacao.agendarAvisoTrabalho(
        id: evento.id, titulo: evento.titulo, materia: evento.materia,
        dataEntrega: evento.data,
      );
      if (!mounted) return;
      setState(() {
        _eventos.putIfAbsent(_normalizar(data), () => []).add(evento);
        _selecionado = _normalizar(data);
        _focado = data;
      });
    }
    titulo.dispose(); materia.dispose(); observacoes.dispose();
  }

  Future<void> _excluir(EventoAcademico evento) async {
    await ServicoNotificacao.cancelar(evento.id);
    _eventos[_normalizar(evento.data)]?.removeWhere((e) => e.id == evento.id);
    final todos = _eventos.values.expand((e) => e).toList();
    await _repositorio.salvar(todos);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final selecionados = _doDia(_selecionado);
    return Scaffold(
      appBar: AppBar(title: const Text('Agenda acadêmica')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _salvarEvento,
        icon: const Icon(Icons.add),
        label: const Text('Adicionar data'),
      ),
      body: _carregando ? const Center(child: CircularProgressIndicator()) :
        ListView(padding: const EdgeInsets.all(12), children: [
          Card(child: Padding(
            padding: const EdgeInsets.all(8),
            child: TableCalendar<EventoAcademico>(
              locale: 'pt_BR',
              firstDay: DateTime.utc(2020, 1, 1),
              lastDay: DateTime.utc(2035, 12, 31),
              focusedDay: _focado,
              selectedDayPredicate: (day) => isSameDay(_selecionado, day),
              eventLoader: _doDia,
              calendarStyle: const CalendarStyle(
                todayDecoration: BoxDecoration(color: Color(0xFFB99AD8), shape: BoxShape.circle),
                selectedDecoration: BoxDecoration(color: Color(0xFF633A8B), shape: BoxShape.circle),
                markerDecoration: BoxDecoration(color: Color(0xFFE3A83B), shape: BoxShape.circle),
              ),
              onDaySelected: (selected, focused) => setState(() {
                _selecionado = _normalizar(selected); _focado = focused;
              }),
              onPageChanged: (focused) => _focado = focused,
              headerStyle: const HeaderStyle(formatButtonVisible: false, titleCentered: true),
            ),
          )),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Text(
              DateFormat('EEEE, dd/MM/yyyy', 'pt_BR').format(_selecionado ?? DateTime.now()),
              style: Theme.of(context).textTheme.titleMedium,
            ),
          ),
          if (selecionados.isEmpty)
            const Padding(padding: EdgeInsets.all(16), child: Text('Nenhum compromisso nesta data.')),
          ...selecionados.map((e) => Card(
            child: ListTile(
              leading: Icon(e.categoria == 'Prova' ? Icons.quiz : Icons.assignment,
                  color: const Color(0xFF704A98)),
              title: Text(e.titulo),
              subtitle: Text('${e.categoria} • ${e.materia}\n${e.observacoes}'),
              isThreeLine: e.observacoes.isNotEmpty,
              trailing: IconButton(icon: const Icon(Icons.delete_outline),
                onPressed: () => _excluir(e)),
            ),
          )),
          const SizedBox(height: 80),
        ]),
    );
  }
}
