import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';

class TracoVetorial {
  final List<Offset> pontos;
  final Color cor;
  final double espessura;
  const TracoVetorial({
    required this.pontos, required this.cor, required this.espessura,
  });
}

class TelaCadernoDigital extends StatefulWidget {
  const TelaCadernoDigital({super.key});
  @override
  State<TelaCadernoDigital> createState() => _TelaCadernoDigitalState();
}

class _TelaCadernoDigitalState extends State<TelaCadernoDigital> {
  final List<TracoVetorial> _tracos = [];
  List<Offset> _pontosAtuais = [];
  Color _corAtual = Colors.black;
  double _espessuraAtual = 3;
  bool _canetaAtiva = false;

  void _finalizarTraco() {
    if (_pontosAtuais.isNotEmpty) {
      _tracos.add(TracoVetorial(
        pontos: List.of(_pontosAtuais),
        cor: _corAtual,
        espessura: _espessuraAtual,
      ));
      _pontosAtuais = [];
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Caderno digital'),
        actions: [
          IconButton(
            tooltip: 'Desfazer',
            icon: const Icon(Icons.undo),
            onPressed: _tracos.isEmpty ? null : () => setState(() => _tracos.removeLast()),
          ),
          IconButton(
            tooltip: 'Limpar página',
            icon: const Icon(Icons.delete_sweep),
            onPressed: () => setState(() { _tracos.clear(); _pontosAtuais.clear(); }),
          ),
        ],
      ),
      body: Column(children: [
        Material(
          color: Colors.white,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Row(children: [
              const Text('Caneta'),
              Switch(value: _canetaAtiva, onChanged: (v) => setState(() => _canetaAtiva = v)),
              const SizedBox(width: 8),
              DropdownButton<Color>(
                value: _corAtual,
                items: [Colors.black, Colors.blue, Colors.red, Colors.green, Colors.purple]
                    .map((c) => DropdownMenuItem(value: c, child: Icon(Icons.circle, color: c)))
                    .toList(),
                onChanged: (c) => setState(() => _corAtual = c!),
              ),
              const SizedBox(width: 12),
              Expanded(child: Slider(
                value: _espessuraAtual, min: 1, max: 10,
                onChanged: (v) => setState(() => _espessuraAtual = v),
              )),
            ]),
          ),
        ),
        Expanded(
          child: Listener(
            behavior: HitTestBehavior.opaque,
            onPointerDown: (event) {
              if (event.kind == PointerDeviceKind.stylus || !_canetaAtiva) {
                if (event.kind == PointerDeviceKind.stylus || event.kind == PointerDeviceKind.invertedStylus) {
                  setState(() => _pontosAtuais = [event.localPosition]);
                } else if (!_canetaAtiva && event.kind == PointerDeviceKind.touch) {
                  setState(() => _pontosAtuais = [event.localPosition]);
                }
              }
            },
            onPointerMove: (event) {
              final permitido = event.kind == PointerDeviceKind.stylus ||
                  event.kind == PointerDeviceKind.invertedStylus ||
                  (!_canetaAtiva && event.kind == PointerDeviceKind.touch);
              if (permitido && _pontosAtuais.isNotEmpty) {
                setState(() => _pontosAtuais.add(event.localPosition));
              }
            },
            onPointerUp: (event) => setState(_finalizarTraco),
            child: RepaintBoundary(
              child: CustomPaint(
                painter: _CanvasPainter(_tracos, _pontosAtuais, _corAtual, _espessuraAtual),
                child: const SizedBox.expand(),
              ),
            ),
          ),
        ),
      ]),
    );
  }
}

class _CanvasPainter extends CustomPainter {
  final List<TracoVetorial> tracos;
  final List<Offset> atuais;
  final Color cor;
  final double espessura;
  _CanvasPainter(this.tracos, this.atuais, this.cor, this.espessura);

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawColor(Colors.white, BlendMode.src);
    final todos = [...tracos, if (atuais.isNotEmpty)
      TracoVetorial(pontos: atuais, cor: cor, espessura: espessura)];
    for (final traco in todos) {
      final p = Paint()
        ..color = traco.cor
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round
        ..strokeWidth = traco.espessura
        ..style = PaintingStyle.stroke;
      if (traco.pontos.length == 1) {
        canvas.drawCircle(traco.pontos.first, traco.espessura / 2, p..style = PaintingStyle.fill);
      } else {
        final path = Path()..moveTo(traco.pontos.first.dx, traco.pontos.first.dy);
        for (final point in traco.pontos.skip(1)) {
          path.lineTo(point.dx, point.dy);
        }
        canvas.drawPath(path, p);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _CanvasPainter oldDelegate) => true;
}
