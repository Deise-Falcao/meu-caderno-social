import 'package:flutter/material.dart';
import 'agenda_screen.dart';
import 'tela_caderno_digital.dart';
import 'estrutura_estudos_screen.dart';

class InicioScreen extends StatelessWidget {
  const InicioScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Meu Caderno Social'),
          Text('Teu espaço de estudos em Serviço Social',
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.normal)),
        ]),
      ),
      body: LayoutBuilder(builder: (context, constraints) {
        final wide = constraints.maxWidth > 700;
        final cards = [
          _Atalho(
            icon: Icons.edit_note_rounded,
            titulo: 'Caderno digital',
            descricao: 'Escreve com tua caneta digital.',
            onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const TelaCadernoDigital())),
          ),
          _Atalho(
            icon: Icons.calendar_month_rounded,
            titulo: 'Agenda acadêmica',
            descricao: 'Organiza provas e trabalhos.',
            onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const AgendaServicoSocial())),
          ),
          _Atalho(
            icon: Icons.folder_copy_rounded,
            titulo: 'Pastas e cadernos',
            descricao: 'Organiza áreas, disciplinas e anotações.',
            onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const EstruturaEstudosScreen())),
          ),
          const _Atalho(
            icon: Icons.menu_book_rounded,
            titulo: 'Biblioteca',
            descricao: 'Espaço reservado para PDFs e leituras.',
          ),
          const _Atalho(
            icon: Icons.balance_rounded,
            titulo: 'Legislação social',
            descricao: 'LOAS, ECA e Código de Ética.',
          ),
          const _Atalho(
            icon: Icons.assignment_rounded,
            titulo: 'Diário de campo',
            descricao: 'Registros do estágio supervisionado.',
          ),
        ];
        return ListView(
          padding: const EdgeInsets.all(18),
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF8055A6), Color(0xFF4E2D70)],
                ),
                borderRadius: BorderRadius.circular(24),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF4E2D70).withOpacity(0.20),
                    blurRadius: 14,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Icon(Icons.auto_stories_rounded, color: Colors.white, size: 38),
                  SizedBox(height: 18),
                  Text(
                    'MEU CADERNO SOCIAL',
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 12,
                      letterSpacing: 2,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Deise Falcão Amaral',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 25,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 6),
                  Text(
                    'Meu espaço de aprendizagem, organização e construção do conhecimento em Serviço Social.',
                    style: TextStyle(color: Colors.white, fontSize: 13, height: 1.4),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 22),
            const Padding(
              padding: EdgeInsets.only(left: 2, bottom: 10),
              child: Text(
                'MEU ESPAÇO DE ESTUDOS',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1,
                  color: Color(0xFF604078),
                ),
              ),
            ),
            GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: wide ? 3 : 2,
              childAspectRatio: wide ? 1.45 : 0.95,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              children: cards,
            ),
          ],
        );
      }),
    );
  }
}

class _Atalho extends StatelessWidget {
  final IconData icon;
  final String titulo;
  final String descricao;
  final VoidCallback? onTap;

  const _Atalho({
    required this.icon,
    required this.titulo,
    required this.descricao,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 34, color: const Color(0xFF704A98)),
              const SizedBox(height: 12),
              Text(titulo, style: const TextStyle(
                  fontWeight: FontWeight.bold, fontSize: 16)),
              const SizedBox(height: 6),
              Text(descricao, style: const TextStyle(fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }
}
