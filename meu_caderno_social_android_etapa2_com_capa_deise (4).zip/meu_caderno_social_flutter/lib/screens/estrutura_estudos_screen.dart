import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/item_estudo.dart';
import '../services/repositorio_estudos.dart';

class EstruturaEstudosScreen extends StatefulWidget {
  const EstruturaEstudosScreen({super.key});
  @override
  State<EstruturaEstudosScreen> createState() => _EstruturaEstudosScreenState();
}

class _EstruturaEstudosScreenState extends State<EstruturaEstudosScreen> {
  final _repo = RepositorioEstudos();
  List<ItemEstudo> _itens = [];
  bool _carregando = true;

  @override
  void initState() {
    super.initState();
    _carregar();
  }

  Future<void> _carregar() async {
    final itens = await _repo.carregar();
    if (!mounted) return;
    setState(() { _itens = itens; _carregando = false; });
  }

  Future<void> _persistir() async => _repo.salvar(_itens);

  List<ItemEstudo> _filhos(String? pai, String tipo) => _itens
      .where((e) => e.paiId == pai && e.tipo == tipo)
      .toList()
    ..sort((a,b) => a.nome.toLowerCase().compareTo(b.nome.toLowerCase()));

  Future<String?> _pedirNome(String titulo, {String inicial = ''}) async {
    final c = TextEditingController(text: inicial);
    return showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(titulo),
        content: TextField(
          controller: c, autofocus: true,
          decoration: const InputDecoration(labelText: 'Nome'),
          textCapitalization: TextCapitalization.sentences,
          onSubmitted: (_) => Navigator.pop(ctx, c.text.trim()),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: const Text('Salvar')),
        ],
      ),
    );
  }

  Future<void> _adicionar(String tipo, String? paiId) async {
    final nome = await _pedirNome(switch(tipo) {
      'area' => 'Nova área de estudo',
      'disciplina' => 'Nova disciplina ou eixo',
      'caderno' => 'Novo caderno',
      _ => 'Nova anotação',
    });
    if (nome == null || nome.trim().isEmpty) return;
    final item = ItemEstudo(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      nome: nome.trim(), tipo: tipo, paiId: paiId,
      atualizadoEm: DateTime.now(),
    );
    setState(() => _itens.add(item));
    await _persistir();
    if (tipo == 'caderno') _abrirCaderno(item);
  }

  Future<void> _renomear(ItemEstudo item) async {
    final nome = await _pedirNome('Renomear', inicial: item.nome);
    if (nome == null || nome.trim().isEmpty) return;
    setState(() {
      final i = _itens.indexWhere((e) => e.id == item.id);
      _itens[i] = item.copiar(nome: nome.trim(), atualizadoEm: DateTime.now());
    });
    await _persistir();
  }

  Future<void> _excluir(ItemEstudo item) async {
    final confirmar = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Excluir item?'),
        content: Text('Deseja excluir "${item.nome}" e os itens que estão dentro dele?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Excluir')),
        ],
      ),
    );
    if (confirmar != true) return;
    final remover = <String>{item.id};
    bool mudou = true;
    while (mudou) {
      mudou = false;
      for (final e in _itens) {
        if (e.paiId != null && remover.contains(e.paiId) && remover.add(e.id)) mudou = true;
      }
    }
    setState(() => _itens.removeWhere((e) => remover.contains(e.id)));
    await _persistir();
  }

  Future<void> _abrirCaderno(ItemEstudo caderno) async {
    final titulo = TextEditingController(text: caderno.nome);
    final texto = TextEditingController(text: caderno.conteudo);
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Anotações do caderno'),
        content: SizedBox(
          width: 620,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: titulo, decoration: const InputDecoration(labelText: 'Título')),
            const SizedBox(height: 12),
            SizedBox(
              height: 300,
              child: TextField(
                controller: texto, expands: true, minLines: null, maxLines: null,
                textAlignVertical: TextAlignVertical.top,
                decoration: const InputDecoration(
                  labelText: 'Escreve tuas anotações aqui',
                  alignLabelWithHint: true,
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            const SizedBox(height: 8),
            const Text('Nesta etapa, as anotações são digitadas. A escrita com caneta e o salvamento dos traços serão integrados na próxima etapa.'),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Fechar')),
          FilledButton(
            onPressed: () async {
              setState(() {
                final i = _itens.indexWhere((e) => e.id == caderno.id);
                if (i >= 0) _itens[i] = caderno.copiar(
                  nome: titulo.text.trim().isEmpty ? caderno.nome : titulo.text.trim(),
                  conteudo: texto.text,
                  atualizadoEm: DateTime.now(),
                );
              });
              await _persistir();
              if (ctx.mounted) Navigator.pop(ctx);
            },
            child: const Text('Salvar'),
          ),
        ],
      ),
    );
  }

  Widget _linha(ItemEstudo item, {required IconData icone, required VoidCallback abrir, required VoidCallback adicionar, bool podeAdicionar = true}) {
    return Card(
      child: ListTile(
        leading: Icon(icone, color: const Color(0xFF70449A)),
        title: Text(item.nome, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text('Atualizado em ${DateFormat('dd/MM/yyyy').format(item.atualizadoEm)}'),
        onTap: abrir,
        trailing: PopupMenuButton<String>(
          onSelected: (v) {
            if (v == 'add') adicionar();
            if (v == 'edit') _renomear(item);
            if (v == 'delete') _excluir(item);
          },
          itemBuilder: (_) => [
            if (podeAdicionar) const PopupMenuItem(value: 'add', child: Text('Adicionar dentro')),
            const PopupMenuItem(value: 'edit', child: Text('Renomear')),
            const PopupMenuItem(value: 'delete', child: Text('Excluir')),
          ],
        ),
      ),
    );
  }

  void _abrirArea(ItemEstudo area) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => _NivelScreen(
      titulo: area.nome,
      subtitulo: 'Disciplinas e eixos de estudo',
      itens: _itens,
      paiId: area.id,
      tipo: 'disciplina',
      proximoTipo: 'caderno',
      onAdicionar: (tipo, pai) => _adicionar(tipo, pai),
      onAbrir: (item) => _abrirNivel(item),
      onEditar: _renomear,
      onExcluir: _excluir,
      onAbrirCaderno: _abrirCaderno,
    )));
  }

  void _abrirNivel(ItemEstudo item) {
    if (item.tipo == 'caderno') { _abrirCaderno(item); return; }
    Navigator.push(context, MaterialPageRoute(builder: (_) => _NivelScreen(
      titulo: item.nome,
      subtitulo: 'Cadernos desta disciplina',
      itens: _itens,
      paiId: item.id,
      tipo: 'caderno',
      proximoTipo: '',
      onAdicionar: (tipo, pai) => _adicionar(tipo, pai),
      onAbrir: _abrirNivel,
      onEditar: _renomear,
      onExcluir: _excluir,
      onAbrirCaderno: _abrirCaderno,
    )));
  }

  @override
  Widget build(BuildContext context) {
    final areas = _filhos(null, 'area');
    return Scaffold(
      appBar: AppBar(title: const Text('Pastas e cadernos')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _adicionar('area', null),
        icon: const Icon(Icons.create_new_folder_outlined),
        label: const Text('Nova área'),
      ),
      body: _carregando ? const Center(child: CircularProgressIndicator())
      : _itens.isEmpty ? const Center(child: Text('Começa criando tua primeira área de estudo.'))
      : ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('MINHAS ÁREAS DE ESTUDO', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1)),
          const SizedBox(height: 10),
          for (final area in areas)
            _linha(area, icone: Icons.folder_special_outlined,
              abrir: () => _abrirArea(area),
              adicionar: () => _adicionar('disciplina', area.id)),
          const SizedBox(height: 80),
        ],
      ),
    );
  }
}

class _NivelScreen extends StatefulWidget {
  final String titulo, subtitulo, tipo, proximoTipo;
  final List<ItemEstudo> itens;
  final String paiId;
  final Future<void> Function(String, String?) onAdicionar;
  final void Function(ItemEstudo) onAbrir;
  final Future<void> Function(ItemEstudo) onEditar, onExcluir;
  final Future<void> Function(ItemEstudo) onAbrirCaderno;

  const _NivelScreen({
    required this.titulo, required this.subtitulo, required this.itens,
    required this.paiId, required this.tipo, required this.proximoTipo,
    required this.onAdicionar, required this.onAbrir, required this.onEditar,
    required this.onExcluir, required this.onAbrirCaderno,
  });

  @override
  State<_NivelScreen> createState() => _NivelScreenState();
}

class _NivelScreenState extends State<_NivelScreen> {
  @override
  Widget build(BuildContext context) {
    final lista = widget.itens.where((e) => e.paiId == widget.paiId && e.tipo == widget.tipo).toList()
      ..sort((a,b) => a.nome.toLowerCase().compareTo(b.nome.toLowerCase()));
    return Scaffold(
      appBar: AppBar(title: Text(widget.titulo)),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => widget.onAdicionar(widget.tipo, widget.paiId),
        icon: const Icon(Icons.add),
        label: Text(widget.tipo == 'disciplina' ? 'Nova disciplina/eixo' : 'Novo caderno'),
      ),
      body: lista.isEmpty
        ? Center(child: Text('Ainda não há itens aqui.\n${widget.subtitulo}', textAlign: TextAlign.center))
        : ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: lista.length,
          itemBuilder: (_, i) {
            final item = lista[i];
            return Card(child: ListTile(
              leading: Icon(widget.tipo == 'disciplina' ? Icons.menu_book_outlined : Icons.book_outlined, color: const Color(0xFF70449A)),
              title: Text(item.nome),
              subtitle: Text(widget.tipo == 'disciplina' ? 'Disciplina ou eixo' : 'Caderno'),
              onTap: () => widget.onAbrir(item),
              trailing: PopupMenuButton<String>(
                onSelected: (v) {
                  if (v == 'edit') widget.onEditar(item);
                  if (v == 'delete') widget.onExcluir(item);
                  if (v == 'add' && widget.proximoTipo.isNotEmpty) widget.onAdicionar(widget.proximoTipo, item.id);
                },
                itemBuilder: (_) => [
                  if (widget.proximoTipo.isNotEmpty) const PopupMenuItem(value: 'add', child: Text('Adicionar dentro')),
                  const PopupMenuItem(value: 'edit', child: Text('Renomear')),
                  const PopupMenuItem(value: 'delete', child: Text('Excluir')),
                ],
              ),
            ));
          },
        ),
    );
  }
}
